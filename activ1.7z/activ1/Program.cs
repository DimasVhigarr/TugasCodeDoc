﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace activ1
{

    class Rerata
    {
        //deklarasi parameter
        double nilaiMTK, nilaiInggris, rerata;

        public void inputData()
        {
            //proses input data
            Console.Write("Masukan Nilai Matematika = ");
            //convert data
            nilaiMTK = Convert.ToDouble(Console.ReadLine());

            Console.Write("Masukan Nilai Bahasa Inggris = ");
            nilaiInggris = Convert.ToDouble(Console.ReadLine());
        }

        //metode function
        public double rumus()
        {
            //rumus rerata
            rerata = (nilaiMTK + nilaiInggris) / 2;
            return rerata;
        }

        //materiutama
        public void output()
        {
            //decision making dengan operator
            if (rumus() >= 80)
            {

                Console.WriteLine("Nilai rerata = " + rumus());
                Console.WriteLine("Anda Mendapatkan Nilai A");
            }
            else if (rumus() < 80 && rumus() >= 70)
            {

                Console.WriteLine("Nilai rerata = " + rumus());
                Console.WriteLine("Anda Mendapatkan Nilai B");
            }
            else if (rumus() < 70 && rumus() >= 60)
            {

                Console.WriteLine("Nilai rerata = " + rumus());
                Console.WriteLine("Anda Mendapatkan Nilai C");
            }
            else
            {

                Console.WriteLine("Nilai rerata = " + rumus());
                Console.WriteLine("Anda Mendapatkan Nilai D");
            }
        }

        internal class Program
        {
            static void Main(string[] args)
            {
                Rerata index = new Rerata();
                index.inputData();
                index.rumus();
                index.output();

                Console.ReadLine();
            }
        }
    }
}